﻿
using UnityEngine;

namespace Impossible.ModMenu
{
    public class ImpossibleLayoutFlag : MonoBehaviour
    {
    }
}
