﻿
using System.Collections.Generic;
using Universal.LanguageLib;

namespace Randomizer.Langs
{
    public class RandomizerLang : LanguageModDict
    {


        public static string Randomizer_enable_plugin = "Randomizer_enable_plugin";
        public static string Randomizer_disable_plugin = "Randomizer_disable_plugin";

        public static string Randomizer_title_plugin = "Randomizer_title_plugin";
        public static string Randomizer_option1_plugin = "Randomizer_option1_plugin";
        public static string Randomizer_option2_plugin = "Randomizer_option2_plugin";
        public static string Randomizer_option3_plugin = "Randomizer_option3_plugin";
        public static string Randomizer_option4_plugin = "Randomizer_option4_plugin";
        public static string Randomizer_option4_plugin_text = "Randomizer_option4_plugin_text";
        public static string Randomizer_option5_plugin = "Randomizer_option5_plugin";
        public static string Randomizer_option6_plugin = "Randomizer_option6_plugin";

        

        public RandomizerLang() : base()
        {

            Dictionary<Language, string> dict = new Dictionary<Language, string>
            {
                { Language.English, "Enable" },
                { Language.French, "Activé" }
            };
            Add(Randomizer_enable_plugin, dict);

            dict = new Dictionary<Language, string>
            {
                { Language.English, "Disable" },
                { Language.French, "Désactive" }
            };
            Add(Randomizer_disable_plugin, dict);

            dict = new Dictionary<Language, string>
            {
                { Language.English, "Spawn" },
                { Language.French, "Spawn" }
            };
            Add(Randomizer_option1_plugin, dict);

            dict = new Dictionary<Language, string>
            {
                { Language.English, "Stats" },
                { Language.French, "Stats" }
            };
            Add(Randomizer_option2_plugin, dict);
            dict = new Dictionary<Language, string>
            {
                { Language.English, "Starters (on pick)" },
                { Language.French, "Starters (on pick)" }
            };
            Add(Randomizer_option3_plugin, dict);

            dict = new Dictionary<Language, string>
            {
                { Language.English, "Reroll" },
                { Language.French, "Reloader" }
            };
            Add(Randomizer_option4_plugin, dict);
            dict = new Dictionary<Language, string>
            {
                { Language.English, "Techs Learn" },
                { Language.French, "Techs Learn" }
            };
            Add(Randomizer_option5_plugin, dict);
            dict = new Dictionary<Language, string>
            {
                { Language.English, "Passive" },
                { Language.French, "Talent" }
            };
            Add(Randomizer_option6_plugin, dict);


            dict = new Dictionary<Language, string>
            {
                { Language.English, "Reroll apply after reloading your game" },
                { Language.French, "Quitter/relancer votre jeu pour reloader" }
            };
            Add(Randomizer_option4_plugin_text, dict);
            dict = new Dictionary<Language, string>
            {
                { Language.English, "Randomizer Plugin" },
                { Language.French, "Randomizer Plugin" }
            };
            Add(Randomizer_title_plugin, dict);



            LangMod.AddLanguageMod("Randomizer", this);
        }


    }
}
