﻿using System;
namespace Randomizer.ModMenu
{
    [Serializable]
    public class Config
    {
        public int randomizerStarterMonsters;
        public int randomizerSpawnMonsters;
        public int randomizerStatsMonsters;
        public int randomizerTechMonsters;
        public int randomizerPassiveMonsters;

        public bool reroll;
    }
}
