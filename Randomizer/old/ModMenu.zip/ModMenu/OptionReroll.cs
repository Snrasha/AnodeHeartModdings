﻿
using Randomizer.Langs;

namespace Randomizer.ModMenu
{
    public class OptionReroll : SettingsOption
    {
        public override string[] getOptions()
        {
            return new string[2]
            {
            StringLocalizer.t(RandomizerLang.Randomizer_enable_plugin),
            StringLocalizer.t(RandomizerLang.Randomizer_disable_plugin)
            };
        }

        public override int getStartingOption()
        {
            return Plugin.randomizerSubMenuGUI.config.reroll?0:1;
        }


        public override void selectOption(int option)
        {
            Plugin.randomizerSubMenuGUI.config.reroll = option == 0;

        }
    }

}
