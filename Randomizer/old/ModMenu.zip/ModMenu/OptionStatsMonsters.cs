﻿
using Randomizer.Langs;

namespace Randomizer.ModMenu
{
    public class OptionStatsMonsters : SettingsOption
    {
        public override string[] getOptions()
        {
            return new string[2]
            {
            StringLocalizer.t(RandomizerLang.Randomizer_enable_plugin),
            StringLocalizer.t(RandomizerLang.Randomizer_disable_plugin)
            };
        }


        public override int getStartingOption()
        {
            return Plugin.randomizerSubMenuGUI.config.randomizerStatsMonsters;
        }


        public override void selectOption(int option)
        {
            Plugin.randomizerSubMenuGUI.config.randomizerStatsMonsters = option;

        }
    }

}
