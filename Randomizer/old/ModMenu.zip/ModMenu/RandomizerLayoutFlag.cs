﻿
using UnityEngine;

namespace Randomizer.ModMenu
{
    public class RandomizerLayoutFlag : MonoBehaviour
    {
    }
}
