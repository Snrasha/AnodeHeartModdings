﻿

using Randomizer.Langs;
using Newtonsoft.Json;
using System;
using System.IO;
using System.Text;
using UnityEngine;
using Universal.EventBusLib;
using Universal.ModMenu;
using Universal.ModMenuLib;
using Randomizer.Scripts;

namespace Randomizer.ModMenu
{
    public class RandomizerSubMenuGUI : SubModMenuInterface
    {
        public Config config;
        public string pathConfig;

        private string pathFolderConfig = "/../BepInEx/plugins/RandomizerConfig";
        private string configname = "/Config.json";
        private string randname_spawn = "/RandSpawn.json";
        private string randname_stats = "/RandStats.json";
        private string randname_techs = "/RandTechs.json";

        public OptionSpawnMonsters optionSpawn;
        public OptionStatsMonsters optionStats;
        public OptionStarters optionStarters;
        public OptionReroll optionReroll;
        public OptionTechMonsters optionTechs;
        public OptionPassiveMonsters optionPassive;





        public RandomizerLayoutFlag randomizerLayoutFlag;



        public RandomizerSubMenuGUI()
        {
            pathConfig = Application.dataPath + pathFolderConfig;

            LoadOptions();
            UniEventBus.AddTypesToEventBus("Randomizer", new Type[] { typeof(OptionSpawnMonsters), typeof(OptionStatsMonsters), typeof(OptionPassiveMonsters), typeof(OptionStarters), typeof(OptionReroll), typeof(OptionTechMonsters) });

            

        }




        public bool CheckIfExist(OptionsController optionsController)
        {
            GameObject childMod = null;

            GameObject frame = optionsController.gameObject.transform.GetChild(0).gameObject;
            foreach (Transform child in frame.transform)
            {
                if (child.gameObject.name.Equals(ModMenuGUI.name))
                {
                    childMod = child.gameObject;
                }
            }
            if (childMod != null)
            {

                randomizerLayoutFlag = childMod.GetComponent<RandomizerLayoutFlag>();

            }


            return randomizerLayoutFlag != null;
        }

        public void CreateModMenu(OptionsController optionsController)
        {
            GameObject childMod = null;

            GameObject frame = optionsController.gameObject.transform.GetChild(0).gameObject;
            foreach (Transform child in frame.transform)
            {
                if (child.gameObject.name.Equals(ModMenuGUI.name))
                {
                    childMod = child.gameObject;
                }
            }
            if (childMod != null)
            {
                randomizerLayoutFlag = childMod.GetComponent<RandomizerLayoutFlag>();
            }
            if (randomizerLayoutFlag == null)
            {

                ModMenuGUI.AddCheckLayout(typeof(RandomizerLayoutFlag));

                GameObject layout=ModMenuGUI.AddLayout("RandomizerLayout");

                ModMenuGUI.CreateText("TextRandomizerTitle", RandomizerLang.Randomizer_title_plugin, ModMenuGUI.overlaytitle, layout);
                ModMenuGUI.CreateText("TextRandomizerDesc", RandomizerLang.Randomizer_option4_plugin_text, ModMenuGUI.overlayDesc, layout);
                optionReroll = ModMenuGUI.CreateButton(typeof(OptionReroll), "RandomizerBtn4", RandomizerLang.Randomizer_option4_plugin, layout).GetComponent<OptionReroll>();
                optionSpawn = ModMenuGUI.CreateButton(typeof(OptionSpawnMonsters), "RandomizerBtn", RandomizerLang.Randomizer_option1_plugin, layout).GetComponent<OptionSpawnMonsters>();
                optionStats = ModMenuGUI.CreateButton(typeof(OptionStatsMonsters), "RandomizerBtn2", RandomizerLang.Randomizer_option2_plugin, layout).GetComponent<OptionStatsMonsters>();
                optionStarters = ModMenuGUI.CreateButton(typeof(OptionStarters), "RandomizerBtn3", RandomizerLang.Randomizer_option3_plugin, layout).GetComponent<OptionStarters>();
                //  optionTechs = ModMenuGUI.CreateButton(typeof(OptionTechMonsters), "RandomizerBtn5", RandomizerLang.Randomizer_option5_plugin, layout).GetComponent<OptionTechMonsters>();
                optionPassive = ModMenuGUI.CreateButton(typeof(OptionPassiveMonsters), "RandomizerBtn6", RandomizerLang.Randomizer_option6_plugin, layout).GetComponent<OptionPassiveMonsters>();

                //optionTamas1.enabled = true;
                //optionTamas2.enabled = true;

            }


        }


        public void LoadOptions()
        {
            if (!Directory.Exists(pathConfig))
            {
                Directory.CreateDirectory(pathConfig);
            }

            LoadConfigFile();
            LoadRand1File();
            LoadRand2File();
            LoadRand3File();


        }


        public void LoadConfigFile()
        {
            if (File.Exists(pathConfig + configname))
            {
                try
                {
                    using (Stream stream = File.OpenRead(pathConfig + configname))
                    {
                        byte[] bytes = new byte[stream.Length];

                        stream.Read(bytes, 0, bytes.Length);

                        string str = Encoding.ASCII.GetString(bytes);
                        try
                        {
                            config = JsonConvert.DeserializeObject<Config>(str);
                            Debug.Log("randomizerSubMenuGUI.config.reroll " +config.reroll);

                        }
                        catch (Exception ex)
                        {
                            Debug.LogError($"Error parsing {pathConfig}: {ex.Message}");
                        }
                    }
                }
                catch
                {
                }
            }
            else
            {
                config = new Config();
                config.randomizerSpawnMonsters = 1;
                config.randomizerStatsMonsters = 1;
                config.randomizerStarterMonsters = 1;
                config.randomizerTechMonsters = 1;
                config.randomizerPassiveMonsters = 1;

                config.reroll = false;

            }
        }
        public void LoadRand1File()
        {
            if (File.Exists(pathConfig + randname_spawn))
            {
                try
                {
                    using (Stream stream = File.OpenRead(pathConfig + randname_spawn))
                    {
                        byte[] bytes = new byte[stream.Length];

                        stream.Read(bytes, 0, bytes.Length);

                        string str = Encoding.ASCII.GetString(bytes);
                        try
                        {
                            Plugin.randomizerSpawn = JsonConvert.DeserializeObject<RandomizerSpawn>(str);
                        }
                        catch (Exception ex)
                        {
                            Debug.LogError($"Error parsing {pathConfig}: {ex.Message}");
                        }
                    }
                }
                catch
                {
                }
            }
            else
            {
                Plugin.randomizerSpawn = new RandomizerSpawn();
            }
        }
        public void LoadRand2File()
        {
            if (File.Exists(pathConfig + randname_stats))
            {
                try
                {
                    using (Stream stream = File.OpenRead(pathConfig + randname_stats))
                    {
                        byte[] bytes = new byte[stream.Length];

                        stream.Read(bytes, 0, bytes.Length);

                        string str = Encoding.ASCII.GetString(bytes);
                        try
                        {
                            Plugin.randomizerStats = JsonConvert.DeserializeObject<RandomizerStats>(str);
                        }
                        catch (Exception ex)
                        {
                            Debug.LogError($"Error parsing {pathConfig}: {ex.Message}");
                        }
                    }
                }
                catch
                {
                }
            }
            else
            {
                Plugin.randomizerStats = new RandomizerStats();
            }
        }
        public void LoadRand3File()
        {
            if (File.Exists(pathConfig + randname_techs))
            {
                try
                {
                    using (Stream stream = File.OpenRead(pathConfig + randname_techs))
                    {
                        byte[] bytes = new byte[stream.Length];

                        stream.Read(bytes, 0, bytes.Length);

                        string str = Encoding.ASCII.GetString(bytes);
                        try
                        {
                            Plugin.randomizerTechs = JsonConvert.DeserializeObject<RandomizerTechs>(str);
                        }
                        catch (Exception ex)
                        {
                            Debug.LogError($"Error parsing {pathConfig}: {ex.Message}");
                        }
                    }
                }
                catch
                {
                }
            }
            else
            {
                Plugin.randomizerTechs = new RandomizerTechs();
            }
        }

        public void SaveConfigFile()
        {
            try
            {
                string textjson = JsonConvert.SerializeObject(config);

                using (Stream stream = File.Open(pathConfig + configname, FileMode.Create))
                {
                    byte[] bytes = Encoding.UTF8.GetBytes(textjson);

                    stream.Write(bytes, 0, bytes.Length);
                }
            }
            catch (Exception e)
            {
                Debug.LogError($"Error saving {pathConfig}: {e.Message}");
            }
            SaveRand1File();
            SaveRand2File();
            SaveRand3File();
        }
        // saveconfigfile is from universal interface
        public void SaveRand1File()
        {
            try
            {
                string textjson = JsonConvert.SerializeObject(Plugin.randomizerSpawn);

                using (Stream stream = File.Open(pathConfig + randname_spawn, FileMode.Create))
                {
                    byte[] bytes = Encoding.UTF8.GetBytes(textjson);

                    stream.Write(bytes, 0, bytes.Length);
                }
            }
            catch (Exception e)
            {
                Debug.LogError($"Error saving {pathConfig}: {e.Message}");
            }
        }
        public void SaveRand2File()
        {
            try
            {
                string textjson = JsonConvert.SerializeObject(Plugin.randomizerStats);

                using (Stream stream = File.Open(pathConfig + randname_stats, FileMode.Create))
                {
                    byte[] bytes = Encoding.UTF8.GetBytes(textjson);

                    stream.Write(bytes, 0, bytes.Length);
                }
            }
            catch (Exception e)
            {
                Debug.LogError($"Error saving {pathConfig}: {e.Message}");
            }
        }
        public void SaveRand3File()
        {
            try
            {
                string textjson = JsonConvert.SerializeObject(Plugin.randomizerTechs);

                using (Stream stream = File.Open(pathConfig + randname_techs, FileMode.Create))
                {
                    byte[] bytes = Encoding.UTF8.GetBytes(textjson);

                    stream.Write(bytes, 0, bytes.Length);
                }
            }
            catch (Exception e)
            {
                Debug.LogError($"Error saving {pathConfig}: {e.Message}");
            }
        }
        public void OnExitOptionsMenu()
        {
        }

        public void OnEnterOptionsMenu()
        {
            if (optionStats != null)
            {
                optionStats.getStartingOption();
            }
            if (optionSpawn != null)
            {
                optionSpawn.getStartingOption();
            }
            if (optionStarters != null)
            {
                optionStarters.getStartingOption();
            }
            if (optionPassive != null)
            {
                optionPassive.getStartingOption();
            }
            if (optionReroll != null)
            {
                optionReroll.getStartingOption();
            }
        }
    }


}
