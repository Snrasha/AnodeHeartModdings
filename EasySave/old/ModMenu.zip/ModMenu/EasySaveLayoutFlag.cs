﻿
using UnityEngine;

namespace EasySave.ModMenu
{
    public class EasySaveLayoutFlag: MonoBehaviour
    {
    }
}
