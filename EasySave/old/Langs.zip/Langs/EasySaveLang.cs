﻿
using System.Collections.Generic;
using Universal.LanguageLib;

namespace EasySave.Langs
{
    public class EasySaveLang:LanguageModDict
    {

        public static string EasySave_desc_plugin = "EasySave_desc_plugin";
        public static string EasySave_title_plugin = "EasySave_title_plugin";
        public static string EasySave_desc1_plugin = "EasySave_desc1_plugin";
        public static string EasySave_desc2_plugin = "EasySave_desc2_plugin";
        public static string EasySave_desc3_plugin = "EasySave_desc3_plugin";



        public EasySaveLang() : base()
        {

            Dictionary<Language, string> dict = new Dictionary<Language, string>
            {
                { Language.English, "F4 for save menu, F6/F9 for quick" },
                { Language.French, "F4 pour sauv., F6/F9 pour instant" }
            };
            Add(EasySave_desc_plugin, dict);

            dict = new Dictionary<Language, string>
            {
                { Language.English, "Key for open the save menu. (Use carefully and not on very weird space)" },
                { Language.French, "Touche pour ouvrir le menu de sauvegarde (à utiliser dans les espaces non étranges)" }
            };
            Add(EasySave_desc1_plugin, dict);
            dict = new Dictionary<Language, string>
            {
                { Language.English, "F4 for save menu, F6/F9 for quick" },
                { Language.French, "F4 pour sauv., F6/F9 pour instant" }
            };
            Add(EasySave_desc2_plugin, dict);
            dict = new Dictionary<Language, string>
            {
                { Language.English, "F4 for save menu, F6/F9 for quick" },
                { Language.French, "F4 pour sauv., F6/F9 pour instant" }
            };
            Add(EasySave_desc3_plugin, dict);

            dict = new Dictionary<Language, string>
            {
                { Language.English, "EasySave Plugin" },
                { Language.French, "EasySave Plugin" }
            };
            Add(EasySave_title_plugin, dict);
           

            LangMod.AddLanguageMod("EasySave", this);
        }


    }
}
